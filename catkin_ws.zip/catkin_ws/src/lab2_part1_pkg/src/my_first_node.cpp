#include <ros/ros.h>

int main(int argc, char **argv){
    ros::init(argc, argv, "hello_world_cpp_node");
    ros::NodeHandle nh;

    //ros::Rate rate(1);
    double pub_freq;
    nh.param("/hello_publish_frequency", pub_freq, 1.0);
    ros::Rate rate(pub_freq);

    while(ros::ok()){
        ROS_INFO("Hello world!");
        rate.sleep();
    }
    return 0;
}