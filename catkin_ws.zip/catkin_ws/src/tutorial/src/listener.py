#!/usr/bin/env python  
import roslib
roslib.load_manifest('listener')
import rospy
import math
import tf
import geometry_msgs.msg
import turtlesim.srv


def add_frame(name):
    br = tf.TransformBroadcaster()
    br.sendTransform((1, 1, 1),
                    (0,0,0),
                    rospy.Time.now(),
                    'base_footprint',
                    name)

if __name__ == '__main__':
    rospy.init_node('tutorial_listener') 
    listener = tf.TransformListener()
    rospy.loginfo("trans %d, rot %d..." % (trans, rot))
    rospy.Subscriber('/new_frame', 
                    string ,
                    add_frame)
    rate = rospy.Rate(10.0)
    while not rospy.is_shutdown():
       try:
            (trans,rot) = listener.lookupTransform('map', 'base_footprint', rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            continue

        rate.sleep()

