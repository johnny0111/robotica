#!/usr/bin/env python  
import roslib
roslib.load_manifest('tutorial')
import rospy
    
import tf
from std_msgs.msg import Float32
    
def handle_altitude(msg):
    br = tf.TransformBroadcaster()
    br.sendTransform((0, 0, msg.data),
                    tf.transformations.quaternion_from_euler(0, 0, 0),
                    rospy.Time.now(),
                    'base_link',
                    'base_footprint')
   
if __name__ == '__main__':
   rospy.init_node('broadcaster')
   rospy.Subscriber('/uav/altitude', 
                    Float32 ,
                    handle_altitude)
   rospy.spin()
