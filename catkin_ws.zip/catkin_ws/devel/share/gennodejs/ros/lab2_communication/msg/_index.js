
"use strict";

let robot_id = require('./robot_id.js');

module.exports = {
  robot_id: robot_id,
};
