#!/usr/bin/env python  
import rospy
import math
import tf


from sensor_msgs.msg import JointState
from tr5_kinematics.srv import DoForwardKinematics, DoForwardKinematicsResponse
from tr5_kinematics.srv import DoInverseKinematics, DoInverseKinematicsResponse
from geometry_msgs.msg import Pose

# load private parameters
svc_fk = rospy.get_param("~for_kin_service", "/do_fk")
svc_ik = rospy.get_param("~inv_kin_service", "/do_ik")     


# DH Parameters for ROB3/TR5
d1 = 0.275
a2 = 0.200
a3 = 0.130
d5 = 0.123




def doForwardKinematics(srv):
    #global model
    #rospy.loginfo("Set_Robot_Model_Service call: %s -> %s" % (model, srv.model))
    #model = srv.model
    ang1 = srv.Joints.position[0]
    ang2 = srv.Joints.position[1]
    ang3 = srv.Joints.position[2]
    ang4 = srv.Joints.position[3]
    
    px = math.cos(ang1)*(a2*math.cos(ang2) + a3*math.cos(ang2 + ang3) + d5*math.cos(ang2+ang3+ang4))
    py = math.sin(ang1)*(a2*math.cos(ang2) + a3*math.cos(ang2 + ang3) + d5*math.cos(ang2+ang3+ang4))
    pz = d1 + a2*math.sin(ang2) + a3*math.sin(ang2 + ang3) + d5*math.sin(ang2+ang3+ang4)
    
    res = Pose()
    res.position.x = px
    res.position.y = py
    res.position.z = pz
    
    return DoForwardKinematicsResponse(res)


def arctan2(y,x):
        if y == 0 and x == 0:
            return 0
        else:
            return math.atan2(y,x)

def root(num):
        if (num < 0):
            return 0
        else:
            return math.sqrt(num)


def doInverseKinematics(srv):
    #global model
    #rospy.loginfo("Set_Robot_Model_Service call: %s -> %s" % (model, srv.model))
    #model = srv.model

    position_x = srv.Cordinates.position.x
    position_y = srv.Cordinates.position.y
    position_z = srv.Cordinates.position.z
    orientation_x = srv.Cordinates.orientation.x
    orientation_y = srv.Cordinates.orientation.y
    orientation_z = srv.Cordinates.orientation.z
    orientation_w = srv.Cordinates.orientation.w

    aux_position = [position_x, position_y, position_z]
    aux_orientation = [orientation_x, orientation_y, orientation_z, orientation_w]

    matriz = tf.TransformerROS().fromTranslationRotation(aux_position,aux_orientation)

    nx = matriz[0][0]
    ny = matriz[1][0]
    nz = matriz[2][0]
    sx = matriz[0][1]
    sy = matriz[1][1]
    sz = matriz[2][1]
    ax = matriz[0][2]
    ay = matriz[1][2]
    az = matriz[2][2]
    px = matriz[0][3]
    py = matriz[1][3]
    pz = matriz[2][3]




    t1 = arctan2(py, px)
    t234 = arctan2(az, ax*math.cos(t1) + ay*math.sin(t1))

    #rospi.loginfo("%d",cost3)
    
    cost3 = (((px*math.cos(t1) + py*math.sin(t1)-d5*math.cos(t234))**2) + ((pz-d1-d5*math.sin(t234))**2) - (a2**2) - (a3**2)) / (2*a2*a3)
    sint3 = root(1-cost3**2)
    t3 = math.atan(root(1/(cost3**2)-1))
    t2 = arctan2(((a2 + a3*math.cos(t3))*(-d1+pz-d5*math.sin(t234))), ((a2+a3*math.cos(t3))*(-d5*math.cos(t234) + math.cos(t1)*px + math.sin(t1)*py)+ a3*math.sin(t3)*(-d1+pz-d5*math.sin(t234))))
    t4 = t234 - t2 - t3
    t5 = math.atan((-ny*math.cos(t1) + nx*math.sin(t1)) / (-sy*math.cos(t1) + sx*math.sin(t1)))

    res = JointState()
    res.header.stamp = rospy.Time.now()
    res.name = ['tr5shoulder_pan_joint','tr5shoulder_lift_joint','tr5elbow_joint','tr5wrist_1_joint','tr5wrist_2_joint','tr5finger_left_joint','tr5finger_right_joint']
    res.position = [t1,t2,t3,t4,t5,0.0,0.0]
    res.effort= []
    res.velocity=[]
    
    return DoInverseKinematicsResponse(res)

if __name__ == "__main__":
    rospy.init_node('tr5_kinematics')
    srv_forward_kinematics = rospy.Service(svc_fk, DoForwardKinematics, doForwardKinematics)
    srv_inverse_kinematics = rospy.Service(svc_ik, DoInverseKinematics, doInverseKinematics)

    while not rospy.is_shutdown():
        rospy.spin()
    