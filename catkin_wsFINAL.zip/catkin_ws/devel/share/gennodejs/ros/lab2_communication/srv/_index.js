
"use strict";

let Set_Robot_Model_Service = require('./Set_Robot_Model_Service.js')

module.exports = {
  Set_Robot_Model_Service: Set_Robot_Model_Service,
};
