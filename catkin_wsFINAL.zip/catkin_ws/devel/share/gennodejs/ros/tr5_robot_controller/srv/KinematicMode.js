// Auto-generated. Do not edit!

// (in-package tr5_robot_controller.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class KinematicModeRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mode_req = null;
    }
    else {
      if (initObj.hasOwnProperty('mode_req')) {
        this.mode_req = initObj.mode_req
      }
      else {
        this.mode_req = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type KinematicModeRequest
    // Serialize message field [mode_req]
    bufferOffset = _serializer.uint8(obj.mode_req, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type KinematicModeRequest
    let len;
    let data = new KinematicModeRequest(null);
    // Deserialize message field [mode_req]
    data.mode_req = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tr5_robot_controller/KinematicModeRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '31f57894870cdab8ae22801b80b21f84';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 mode_req
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new KinematicModeRequest(null);
    if (msg.mode_req !== undefined) {
      resolved.mode_req = msg.mode_req;
    }
    else {
      resolved.mode_req = 0
    }

    return resolved;
    }
};

class KinematicModeResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mode_res = null;
    }
    else {
      if (initObj.hasOwnProperty('mode_res')) {
        this.mode_res = initObj.mode_res
      }
      else {
        this.mode_res = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type KinematicModeResponse
    // Serialize message field [mode_res]
    bufferOffset = _serializer.bool(obj.mode_res, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type KinematicModeResponse
    let len;
    let data = new KinematicModeResponse(null);
    // Deserialize message field [mode_res]
    data.mode_res = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'tr5_robot_controller/KinematicModeResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cffd7e77e2e867af00910762dea87fe4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool mode_res
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new KinematicModeResponse(null);
    if (msg.mode_res !== undefined) {
      resolved.mode_res = msg.mode_res;
    }
    else {
      resolved.mode_res = false
    }

    return resolved;
    }
};

module.exports = {
  Request: KinematicModeRequest,
  Response: KinematicModeResponse,
  md5sum() { return 'd4d18d0f53106e25dd7cf4538201fdfe'; },
  datatype() { return 'tr5_robot_controller/KinematicMode'; }
};
