// Auto-generated. Do not edit!

// (in-package lab2_communication.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let robot_id = require('../msg/robot_id.js');

//-----------------------------------------------------------

class Set_Robot_Model_ServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.model = null;
    }
    else {
      if (initObj.hasOwnProperty('model')) {
        this.model = initObj.model
      }
      else {
        this.model = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Set_Robot_Model_ServiceRequest
    // Serialize message field [model]
    bufferOffset = _serializer.string(obj.model, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Set_Robot_Model_ServiceRequest
    let len;
    let data = new Set_Robot_Model_ServiceRequest(null);
    // Deserialize message field [model]
    data.model = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.model.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'lab2_communication/Set_Robot_Model_ServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0147e4f36cba5cda7fa39c089e493413';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string model
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Set_Robot_Model_ServiceRequest(null);
    if (msg.model !== undefined) {
      resolved.model = msg.model;
    }
    else {
      resolved.model = ''
    }

    return resolved;
    }
};

class Set_Robot_Model_ServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.robot_id = null;
    }
    else {
      if (initObj.hasOwnProperty('robot_id')) {
        this.robot_id = initObj.robot_id
      }
      else {
        this.robot_id = new robot_id();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Set_Robot_Model_ServiceResponse
    // Serialize message field [robot_id]
    bufferOffset = robot_id.serialize(obj.robot_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Set_Robot_Model_ServiceResponse
    let len;
    let data = new Set_Robot_Model_ServiceResponse(null);
    // Deserialize message field [robot_id]
    data.robot_id = robot_id.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += robot_id.getMessageSize(object.robot_id);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'lab2_communication/Set_Robot_Model_ServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '752e04e8a5edfa3b4ad6247d716b14bb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    lab2_communication/robot_id robot_id
    
    ================================================================================
    MSG: lab2_communication/robot_id
    Header header 
    int8 id
    string model
    
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Set_Robot_Model_ServiceResponse(null);
    if (msg.robot_id !== undefined) {
      resolved.robot_id = robot_id.Resolve(msg.robot_id)
    }
    else {
      resolved.robot_id = new robot_id()
    }

    return resolved;
    }
};

module.exports = {
  Request: Set_Robot_Model_ServiceRequest,
  Response: Set_Robot_Model_ServiceResponse,
  md5sum() { return '20e07c294cb8665d25641d4e40cf780a'; },
  datatype() { return 'lab2_communication/Set_Robot_Model_Service'; }
};
